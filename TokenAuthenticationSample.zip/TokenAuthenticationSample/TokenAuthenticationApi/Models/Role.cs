﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TokenAuthenticationApi.Models
{
    [Table("Roles")]
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string Description { get; set; }
    }
}
