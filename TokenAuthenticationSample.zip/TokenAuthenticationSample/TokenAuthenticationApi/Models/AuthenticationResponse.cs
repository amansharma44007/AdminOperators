﻿namespace TokenAuthenticationApi.Models
{
    public class AuthenticationResponse
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FriendlyName { get; set; }
        public string Token { get; set; }
        public AuthenticationResponse() { }
        public AuthenticationResponse(User user, string token)
        {
            (UserId, UserName, FriendlyName) = user;
            Token = token;
        }
    }
}
