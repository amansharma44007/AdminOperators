﻿using Microsoft.EntityFrameworkCore;

namespace TokenAuthenticationApi.Models
{
    public class UsersDbContext : Microsoft.EntityFrameworkCore.DbContext

    {
        public UsersDbContext(DbContextOptions<UsersDbContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {

            optionsBuilder.UseSqlServer(

                connectionString: @"server=(localdb)\MSSQLLocalDB;database=UsersDB;integrated security=sspi;MultipleActiveResultSets=true"

        );

        }

        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Role> Roles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserRole>().HasKey("UserId", "RoleId");
        }

    }
}
