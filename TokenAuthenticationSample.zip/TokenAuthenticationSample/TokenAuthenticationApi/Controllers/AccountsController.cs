﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TokenAuthenticationApi.Models;
using TokenAuthenticationApi.Services;

namespace TokenAuthenticationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        IUserService _service;
        public AccountsController(IUserService user)
        {
            _service = user;
        }
        [HttpPost(template:"authenticate")]
        public IActionResult Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var authResponse=_service.Autheticate(model);
            if(authResponse is null)
            {
                return Unauthorized();
            }
            else
            {
                return Ok(authResponse);
            }
        }
        [HttpGet(template:"validate")]
        [CustomAuthorize]
        public IActionResult ValidateToken()
        {
            var user = HttpContext.Items["User"] as User;
            var role = HttpContext.Items["Role"] as Role;
            if (user is null || role is null)
                return NotFound();
            var obj = new {User=user,Role=role};
            return Ok(obj);
        }
        [HttpGet(template: "logout")]
        [CustomAuthorize]
        public IActionResult Logout()
        {
            return Ok();
        }
    }
}
