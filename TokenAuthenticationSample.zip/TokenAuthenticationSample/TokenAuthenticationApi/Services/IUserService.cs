﻿using TokenAuthenticationApi.Models;

namespace TokenAuthenticationApi.Services
{
    public interface IUserService
    {
        AuthenticationResponse Autheticate(LoginModel model);
        User LoggedUser { get; set; }
        Role GetRole(int userId);
        User GetByName(string name);
    }
}
