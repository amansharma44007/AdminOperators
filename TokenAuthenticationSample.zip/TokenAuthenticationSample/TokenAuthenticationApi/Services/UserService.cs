﻿using TokenAuthenticationApi.Models;
using System.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace TokenAuthenticationApi.Services
{
    public class UserService : IUserService
    {
        UsersDbContext _db;


        public UserService(UsersDbContext db)
        {
            _db= db;
        }
        public User LoggedUser { get; set; }
        

        public AuthenticationResponse Autheticate(LoginModel model)
        {
            var user = _db.Users.FirstOrDefault(x => x.UserName == model.UserName && x.Password==model.Password);
            if (user is null)
                return null;
            LoggedUser = user;
            var role = GetRole(user.UserId);
            JwtSecurityTokenHandler tokenHandler = new();
            var claimIdentity = new ClaimsIdentity(new[]
            {
                new Claim("Username",user.UserName),
                new Claim("Role",role.RoleName)
            });
            var keyBytes = System.Text.Encoding.UTF8.GetBytes("AssitEdgeDotNetTrainingForEdgeVerve");
            var signingCredentials = new SigningCredentials(
                key:new SymmetricSecurityKey(keyBytes),
                algorithm:SecurityAlgorithms.HmacSha256Signature);
            SecurityTokenDescriptor tokenDescriptor = new()
            {
                Subject = claimIdentity,
                Expires = System.DateTime.UtcNow.AddDays(1),
                SigningCredentials = signingCredentials
            };
            var preToken = tokenHandler.CreateToken(tokenDescriptor);
            var token = tokenHandler.WriteToken(preToken);
            var authResponse = new AuthenticationResponse(user, token);
            return authResponse;
        }

        public User GetByName(string name)
        {
            var user = _db.Users.FirstOrDefault(c => c.UserName == name);
            if (user!=null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public Role GetRole(int userId)
        {
            var userMapping = _db.UserRoles.Where(c => c.UserId == userId).ToList();
            var role=_db.Roles.FirstOrDefault(c=>c.RoleId == userMapping.FirstOrDefault().RoleId);
            return role;
        }
    }
}
