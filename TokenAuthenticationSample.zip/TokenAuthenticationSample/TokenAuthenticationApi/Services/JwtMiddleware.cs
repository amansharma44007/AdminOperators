﻿using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace TokenAuthenticationApi.Services
{
    public class JwtMiddleware
    {
        //private readonly IUserService _userService;
        
        private readonly RequestDelegate _next;
        public JwtMiddleware(RequestDelegate next)
        {
            _next= next;
        }
        public async Task Invoke(HttpContext context, IUserService service)
        {
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(' ').Last();
            if (!string.IsNullOrEmpty(token))
            {
                var key=System.Text.Encoding.UTF8.GetBytes("AssitEdgeDotNetTrainingForEdgeVerve");
                var signingKey = new SymmetricSecurityKey(key);
                JwtSecurityTokenHandler tokenHandler = new();
                var tokenValidationParamter = new TokenValidationParameters()
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = signingKey,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = System.TimeSpan.Zero
                };
                tokenHandler.ValidateToken(
                    token:token,
                    validationParameters:tokenValidationParamter,
                    validatedToken:out SecurityToken validatedToken);
                var jwtToken = validatedToken as JwtSecurityToken;
                var username = jwtToken.Claims.FirstOrDefault(c => c.Type == "Username").Value;
                var role = jwtToken.Claims.FirstOrDefault(c => c.Type == "Role").Value;
                var user = service.GetByName(username);
                context.Items["User"] = user;
                context.Items["Role"] = service.GetRole(user.UserId);
            }
            await _next(context);
        }
    }
}
