﻿using EmployeesWebApi.Infrastructure;
using EmployeesWebApi.Models;
using EmployeesWebApi.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace EmployeesWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class EmployeesController : ControllerBase
    {
        IEmployeeService<Employee, string> _repository;
        public EmployeesController(IEmployeeService<Employee, string> employeeService)
        {
            _repository = employeeService;
        }
        [HttpGet]
        [CustomAuthorize("Admin")]  
        
        public ActionResult<IEnumerable<Employee>> Get()
        {
            var item = _repository.GetAll();
            return Ok(item);
        }
        [HttpGet("{id}")]
        [CustomAuthorize("Admin")]
        public IActionResult GetBy(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();
            var item = _repository.GetById(id);
            return Ok(item);
        }
        [HttpGet(template: "findby/{criteria}")]
        [CustomAuthorize("Admin")]
        public ActionResult<IEnumerable<Employee>> FilterBy(string criteria)
        {
            IEnumerable<Employee> items = null;
            if (string.IsNullOrEmpty(criteria))
                items = _repository.GetAll();
            else
                items = _repository.GetBy(criteria);

            return items.ToList();

        }
        [HttpGet(template: "birthMonth/{criteria}")]
        [CustomAuthorize("Admin")]
        public ActionResult<IEnumerable<Employee>> FilterByMonth(string criteria)
        {
            IEnumerable<Employee> items = null;
            if (string.IsNullOrEmpty(criteria))
                items = _repository.GetBy(criteria);
            else
                
                items = _repository.GetByBirthDate(criteria.ToLower());

            return items.ToList();

        }
        [HttpPost(template: "create")]
        [CustomAuthorize("Admin")]
        public IActionResult CreateNew(Employee model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("ModelState");
            }
            _repository.Upsert(model);
            return Created(uri: "", value: model);
        }
        [HttpPut(template: "update/{id}")]
        [CustomAuthorize("Admin")]
        public ActionResult<Employee> Upsert(string id, Employee item)
        {
            if (int.Parse(id) != item.EmployeeId)
                return BadRequest();
            _repository.Upsert(item);

            return Ok(item);
        }

    }
}
