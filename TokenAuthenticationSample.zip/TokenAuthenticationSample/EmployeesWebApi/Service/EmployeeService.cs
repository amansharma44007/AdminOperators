﻿using EmployeesWebApi.DBContext;
using EmployeesWebApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace EmployeesWebApi.Service
{
    public class EmployeeService : IEmployeeService<Employee, string>
    {
        AEDBContext _db;
        public EmployeeService(AEDBContext db)
        {_db = db;}

        public void Delete(string id)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Employee> GetAll()
        {
            return _db.Employees.AsNoTracking().ToList();
        }

        public IEnumerable<Employee> GetBy(string filter)
        {
            return _db.Employees.Where(c => c.FirstName.Contains(filter) ||
             c.LastName.Contains(filter)).ToList();
        }

        public IEnumerable<Employee> GetByBirthDate(string month)
        {
            Dictionary<string, int> months = new Dictionary<string, int>()
            {
                { "january", 1},
                { "february", 2},
                { "march", 3},
                { "april", 4},
                { "may", 5},
                { "june", 6},
                { "july", 7},
                { "august", 8},
                { "september", 9},
                { "october", 10},
                { "november", 11},
                { "december", 12},
            };
            var monthInt=months[month];
            var items= _db.Employees.Where(c => c.BirthDate.Month==monthInt).ToList();
            return items;
        }

        public Employee GetById(string id)
        {
            return _db.Employees.AsNoTracking().FirstOrDefault(c=>c.EmployeeId==int.Parse(id));
        }

        public void Upsert(Employee item)
        {
            var Obj = _db.Employees.AsNoTracking().FirstOrDefault(c => c.EmployeeId == item.EmployeeId);
            if (Obj == null)
            {
                _db.Employees.Add(item);
            }
            else
            {
                _db.Employees.Update(item);

            }
            _db.SaveChanges();
        }
    }
}
