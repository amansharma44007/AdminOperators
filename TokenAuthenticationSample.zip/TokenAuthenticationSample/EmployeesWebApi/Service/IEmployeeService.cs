﻿using System.Collections.Generic;

namespace EmployeesWebApi.Service
{
    public interface IEmployeeService<TEntity, TIdentity>
    {
        IEnumerable<TEntity> GetAll();
        TEntity GetById(TIdentity id);
        IEnumerable<TEntity> GetBy(string filter);
        void Upsert(TEntity item);
        void Delete(TIdentity id);
        IEnumerable<TEntity> GetByBirthDate(string month);
    }
}
