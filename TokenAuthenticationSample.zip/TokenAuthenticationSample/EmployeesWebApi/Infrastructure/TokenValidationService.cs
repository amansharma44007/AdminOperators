﻿using EmployeesWebApi.Models;
using Microsoft.Extensions.Options;
using System.Net.Http;
using System;
using System.Text.Json;

namespace EmployeesWebApi.Infrastructure
{
    class TempClass
    {
        public User User { get; set; }
        public Role Role { get; set; }
    }
    public class TokenValidationService : ITokenValidationService
    {
        private readonly AppSetting _setting;
        public TokenValidationService(IOptions<AppSetting> settings)
        {
            _setting = settings.Value;
        }
        public User LoggedIn {get;protected set;}

        public Role UserInRole { get; protected set; }

        public bool ValidateToken(string token)
        {
            using(HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_setting.TokenApiBaseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",token);
                var response = client.GetAsync(_setting.TokenApiValidateUrl).Result;
                var result=response.Content.ReadAsStringAsync().Result;
                var obj=JsonSerializer.Deserialize<TempClass>(result,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive=true});
                UserInRole = obj.Role;
                LoggedIn = obj.User;
                if (UserInRole is not null && LoggedIn is not null)
                    return true;
                else
                    return false;
    
            }
        }
    }
}
