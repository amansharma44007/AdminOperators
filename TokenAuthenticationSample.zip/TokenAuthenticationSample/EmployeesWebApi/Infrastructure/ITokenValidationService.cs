﻿using EmployeesWebApi.Models;

namespace EmployeesWebApi.Infrastructure
{
    public interface ITokenValidationService
    {
        bool ValidateToken(string token);
        User LoggedIn { get; }
        Role UserInRole { get; }
    }
}
