﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeesWebApi.Infrastructure
{
    
    public class TokenValidatorMiddleware
    {
        private readonly RequestDelegate _next;
        public TokenValidatorMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task Invoke(HttpContext context,ITokenValidationService service)
        {
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(' ')[1];
            if(token is not null)
            {
                service.ValidateToken(token);
                if (service.LoggedIn is not null)
                    context.Items["User"] = service.LoggedIn;
                if (service.UserInRole is not null)
                    context.Items["Role"] = service.UserInRole;
            }
            await _next(context);
        }
    }
}
