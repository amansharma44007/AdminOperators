﻿using EmployeesWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
namespace EmployeesWebApi.Infrastructure
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method, AllowMultiple = true)]
    public class CustomAuthorizeAttribute:Attribute,IAuthorizationFilter
    {
        string desiredRole=string.Empty;
        //string[] desiredRole = new string[2];
        public CustomAuthorizeAttribute(string roleName="")
        {
            desiredRole = roleName;
            //desiredRole = roleName.Split(",");
        }
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var user = context.HttpContext?.Items["User"] as User;
            if(user is null)
            {
                context.Result = new JsonResult(
                    new
                    {
                        message = "You are not authorized to use this application.Contact your admin."
                    })
                {
                    StatusCode = StatusCodes.Status401Unauthorized
                };
            }
            if (!string.IsNullOrEmpty(desiredRole))
            {
                var role = context.HttpContext?.Items["Role"] as Role;
                if (role.RoleName.ToLower() != desiredRole.ToLower())
                {
                    context.Result = new JsonResult(
                        new
                        {
                            message = "You are not authorized to use this api.COntact the admin"
                        }
                    )
                    {
                        StatusCode = StatusCodes.Status401Unauthorized
                    };

                }
            }
            
            

        }
    }
}
