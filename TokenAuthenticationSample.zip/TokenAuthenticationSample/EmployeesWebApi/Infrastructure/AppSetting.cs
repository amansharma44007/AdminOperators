﻿namespace EmployeesWebApi.Infrastructure
{
    public class AppSetting
    {
        public string TokenApiBaseAddress { get; set; }
        public string TokenApiValidateUrl { get; set; }
    }
}
