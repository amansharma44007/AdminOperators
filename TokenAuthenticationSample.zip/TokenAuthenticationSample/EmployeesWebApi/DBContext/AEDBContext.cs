﻿using EmployeesWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeesWebApi.DBContext
{
    public class AEDBContext : DbContext
    {
        public AEDBContext(DbContextOptions<AEDBContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }

    }
}
