﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using TokenAuthenticationApi.Models;
using TokenAuthenticationApi.Services;

namespace UI
{
    public class LoginUI
    {
        public String[] Login(string baseAddress,string apiAddress,IUserService userService)
        {
            Console.Clear();
            String[] Role = new String[2];
            LoginModel u1 = new LoginModel();
            Console.Write("Enter the UserName: ");
            u1.UserName = Console.ReadLine();
            Console.Write("Enter the Password: ");
            u1.Password = Console.ReadLine();



            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));

                var content = JsonContent.Create<LoginModel>(
                    inputValue: u1,
                    mediaType: new MediaTypeHeaderValue("application/json"),
                    options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }

    );
                try
                {
                    var response = client.PostAsync(requestUri: $"{apiAddress}/authenticate", content: content).Result;
                    response.EnsureSuccessStatusCode();
                    var responseString = response.Content.ReadAsStringAsync().Result;
                    var data = JsonSerializer.Deserialize<AuthenticationResponse>(
                        json: responseString,
                        options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                        );
                    Console.WriteLine("You are be Authorized as: " + data.Token);
                    Role[0] = userService.GetRole(data.UserId).RoleName;
                    Console.WriteLine("You are :"+Role[0]);
                    Role[1] = data.Token;
                    Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                    Console.ReadKey();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Invalid Credentials");
                }

            }
            return Role;

        }
    }
}
