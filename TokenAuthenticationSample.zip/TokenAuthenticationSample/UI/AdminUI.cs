﻿using EmployeesWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace UI
{
    public class AdminUI
    {
        void FetchAllEmployee(string token)
        {
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees/";
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync(apiAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    var dataString = response.Content.ReadAsStringAsync().Result;
                    System.Text.Json.JsonSerializerOptions options = new System.Text.Json.JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                    };
                    var data = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Employee>>(dataString, options);
                    if (data != null)
                    {
                        data = data.ToList();
                        foreach (var data1 in data)
                        {
                            Console.WriteLine("***************************************************");
                            Console.WriteLine($"FirstName: {data1.FirstName}\nLastName: {data1.LastName}\nTitle {data1.Title}" +
                                $"\nCity: {data1.City}");
                            Console.WriteLine("***************************************************");
                        }
                        Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                        Console.ReadKey();
                    }
                }
            }
        }
        void FetchCustomer(string token)
        {
            Console.Clear();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees";
            Console.Write("Enter the Employee Id: ");
            int custId = int.Parse(Console.ReadLine());
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync($"{apiAddress}/{custId}").Result;
                response.EnsureSuccessStatusCode();
                var responseString = response.Content.ReadAsStringAsync().Result;
                var data = JsonSerializer.Deserialize<Employee>(
                    json: responseString,
                    options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                    );
                Console.WriteLine("***************************************************");
                Console.WriteLine($"FirstName: {data.FirstName}\nLastName: {data.LastName}\nTitle {data.Title}" +
                    $"\nCity: {data.City}");
                Console.WriteLine("***************************************************");
                Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                Console.ReadKey();
            }
        }
        void UpdateEmployee(string token)
        {
            Console.Clear();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees";
            Console.Write("Enter the Employee Id that you want to change:");
            int custId = int.Parse(Console.ReadLine());
            bool a = true;
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync($"{apiAddress}/{custId}").Result;
                response.EnsureSuccessStatusCode();
                var responseString = response.Content.ReadAsStringAsync().Result;
                if (responseString == "")
                {
                    a = false;
                    Console.WriteLine("There is no Id present in the database");
                    Console.WriteLine("Press Any Key to Continue!!");
                    Console.ReadKey();
                }
                else
                {
                    var data = JsonSerializer.Deserialize<Employee>(
                    json: responseString,
                    options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                    );
                }



            }
            if (a)
            {
                Employee e1 = new Employee();
                baseAddress = "http://localhost:64721/";
                apiAddress = "api/Employees/update";
                Console.Write("Enter the Employee Id: ");
                e1.EmployeeId = int.Parse(Console.ReadLine());
                Console.Write("Enter the First Name: ");
                e1.FirstName = Console.ReadLine();
                Console.Write("Enter the lastName: ");
                e1.LastName = Console.ReadLine();
                Console.Write("Enter the title: ");
                e1.Title = Console.ReadLine();
                Console.Write("Enter the Address: ");
                e1.Address = Console.ReadLine();
                Console.Write("Enter the BirthDate: ");
                e1.BirthDate = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter the City: ");
                e1.City = Console.ReadLine();
                Console.Write("Enter the Hire Date: ");
                e1.HireDate = DateTime.Parse(Console.ReadLine());

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(baseAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                    var content = JsonContent.Create<Employee>(
                        inputValue: e1,
                        mediaType: new MediaTypeHeaderValue("application/json"),
                        options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }

        );
                    try
                    {
                        var response = client.PutAsync(requestUri: $"{apiAddress}/{custId}", content: content).Result;
                        response.EnsureSuccessStatusCode();
                        var responseString = response.Content.ReadAsStringAsync().Result;
                        var data = JsonSerializer.Deserialize<Employee>(
                            json: responseString,
                            options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                            );
                        Console.WriteLine("Updated!!!");
                        Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                        Console.ReadKey();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        Console.WriteLine("Press Any Key to Continue!!");
                        Console.ReadKey();
                    }

                }
            }

        }
        void CreateNewEmployee(string token)
        {
            Console.Clear();
            Employee e1 = new Employee();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees";
            Console.Write("Enter the First Name: ");
            e1.FirstName = Console.ReadLine();
            Console.Write("Enter the lastName: ");
            e1.LastName = Console.ReadLine();
            Console.Write("Enter the title: ");
            e1.Title = Console.ReadLine();
            Console.Write("Enter the Address: ");
            e1.Address = Console.ReadLine();
            Console.Write("Enter the BirthDate: ");
            e1.BirthDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter the City: ");
            e1.City = Console.ReadLine();
            Console.Write("Enter the Hire Date: ");
            e1.HireDate = DateTime.Parse(Console.ReadLine());
            

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var content = JsonContent.Create<Employee>(
                    inputValue: e1,
                    mediaType: new MediaTypeHeaderValue("application/json"),
                    options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }

    );
                try
                {
                    var response = client.PostAsync(requestUri: $"{apiAddress}/create", content: content).Result;
                    response.EnsureSuccessStatusCode();
                    var responseString = response.Content.ReadAsStringAsync().Result;
                    var data = JsonSerializer.Deserialize<Employee>(
                        json: responseString,
                        options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                        );
                    Console.WriteLine("Data has been Inserted!!!!!");
                    Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                    Console.ReadKey();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }

        }
        void FetchAllEmployeeByBirthMonth(string token)
        {
            Console.Clear();
            Console.Write("Enter the Month Name: ");
            string custMonth = Console.ReadLine();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = $"api/Employees/birthMonth/{custMonth}";
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync(apiAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    var dataString = response.Content.ReadAsStringAsync().Result;
                    System.Text.Json.JsonSerializerOptions options = new System.Text.Json.JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                    };
                    var data = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Employee>>(dataString, options);
                    if (data != null)
                    {
                        data = data.ToList();
                        foreach (var data1 in data)
                        {
                            Console.WriteLine("***************************************************");
                            Console.WriteLine($"FirstName: {data1.FirstName}\nLastName: {data1.LastName}\nTitle {data1.Title}" +
                                $"\nCity: {data1.City}");
                            Console.WriteLine("***************************************************");
                        }
                        Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                        Console.ReadKey();
                    }
                }
            }
        }

        public AdminUI(string token)
        {
            bool a = true;
            while (a)
            {
            Console.Clear();
            Console.WriteLine("Welcome to Admin System");
            Console.WriteLine("\t1.View All The Employees");
            Console.WriteLine("\t2. View Employee By Id");
            Console.WriteLine("\t3. View Employees By Birth Month");
            Console.WriteLine("\t4. Insert Employee");
            Console.WriteLine("\t5. Update Employee");
            Console.WriteLine("\t6. Exit");
            Console.Write("Please Enter Your Choice: ");
            var choice = Console.ReadLine();
            
            
                switch (choice)
                {
                    case "1":
                        FetchAllEmployee(token);
                        break;
                    case "2":
                        FetchCustomer(token);
                        break;
                    case "3":
                        FetchAllEmployeeByBirthMonth(token);
                        break;
                    case "4":
                        CreateNewEmployee(token);
                        break;
                    case "5":
                        UpdateEmployee(token);
                        break;
                    case "6":
                        a = false;
                        break;
                    default: Console.WriteLine("Please Enter Valid Input");Console.ReadKey()
                            ; break;
                }
            }
            
        }
    }
}
