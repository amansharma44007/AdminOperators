﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using TokenAuthenticationApi.Models;
using TokenAuthenticationApi.Services;

namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var collection = new ServiceCollection();
            collection.AddScoped<IUserService, UserService>();
            collection.AddDbContext<UsersDbContext>(option =>
            {
                option.UseSqlServer(connectionString: "server=(localdb)\\mssqllocaldb;initial catalog=UsersDB; integrated security=sspi;");
            });
            IServiceProvider serviceProvider = collection.BuildServiceProvider();
            
            var userService = serviceProvider.GetService<IUserService>();
            string baseAddress = "http://localhost:53651/";
            string apiAddress = "api/accounts";
            LoginUI loginUI = new LoginUI();
            var role=loginUI.Login(baseAddress,apiAddress,userService);
            if (role[0] == "Admin")
            {
                AdminUI adminUI = new AdminUI(role[1]);
            }
            if (role[0] == "Operators")
            {
                OperatorsUI operatorUI = new OperatorsUI(role[1]); 
            }
        }
    }
}
  