﻿using EmployeesWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace UI
{
    public  class OperatorsUI
    {
        void FetchAllEmployee(string token)
        {
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees/";
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync(apiAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    var dataString = response.Content.ReadAsStringAsync().Result;
                    System.Text.Json.JsonSerializerOptions options = new System.Text.Json.JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                    };
                    var data = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Employee>>(dataString, options);
                    if (data != null)
                    {
                        data = data.ToList();
                        foreach (var data1 in data)
                        {
                            Console.WriteLine("***************************************************");
                            Console.WriteLine($"FirstName: {data1.FirstName}\nLastName: {data1.LastName}\nTitle {data1.Title}" +
                                $"\nCity: {data1.City}");
                            Console.WriteLine("***************************************************");
                        }
                        Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                        Console.ReadKey();
                    }
                }
            }
        }
        void FetchEmployee(string token)
        {
            Console.Clear();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = "api/Employees";
            Console.Write("Enter the Employee Id: ");
            int custId = int.Parse(Console.ReadLine());
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync($"{apiAddress}/{custId}").Result;
                response.EnsureSuccessStatusCode();
                var responseString = response.Content.ReadAsStringAsync().Result;
                var data = JsonSerializer.Deserialize<Employee>(
                    json: responseString,
                    options: new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                    );
                Console.WriteLine("***************************************************");
                Console.WriteLine($"FirstName: {data.FirstName}\nLastName: {data.LastName}\nTitle {data.Title}" +
                    $"\nCity: {data.City}");
                Console.WriteLine("***************************************************");
                Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                Console.ReadKey();
            }
        }
        void FetchAllEmployeeByBirthMonth(string token)
        {
            Console.Clear();
            Console.Write("Enter the Month Name: ");
            string custMonth = Console.ReadLine();
            string baseAddress = "http://localhost:64721/";
            string apiAddress = $"api/Employees/birthMonth/{custMonth}";
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", $"{token}");
                var response = client.GetAsync(apiAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    var dataString = response.Content.ReadAsStringAsync().Result;
                    System.Text.Json.JsonSerializerOptions options = new System.Text.Json.JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                    };
                    var data = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Employee>>(dataString, options);
                    if (data != null)
                    {
                        data = data.ToList();
                        foreach (var data1 in data)
                        {
                            Console.WriteLine("***************************************************");
                            Console.WriteLine($"FirstName: {data1.FirstName}\nLastName: {data1.LastName}\nTitle {data1.Title}" +
                                $"\nCity: {data1.City}");
                            Console.WriteLine("***************************************************");
                        }
                        Console.WriteLine("\n\n Please Enter the Key to Continue!!!");
                        Console.ReadKey();
                    }
                }
            }
        }
        public OperatorsUI(string token)
        {
            bool a = true;
            while (a)
            {
                Console.Clear();
                Console.WriteLine("Welcome To Operators System");

                Console.WriteLine("\t1.View All The Employees");
                Console.WriteLine("\t2. View Employee By Id");
                Console.WriteLine("\t3. View Employees By Birth Month");
                Console.WriteLine("\t4. Back to Menu");
                Console.Write("Please Enter Your Choice: ");
                var choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        FetchAllEmployee(token);
                        break;
                    case "2":
                        FetchEmployee(token);
                        break;
                    case "3":
                        FetchAllEmployeeByBirthMonth(token);
                        break;
                    case "4":
                        a = false;
                        break;
                    default: Console.WriteLine("Please Enter Valid Input");
                            Console.ReadKey(); break;
                }
            }
            
        }
    }
}
